package com.smart.Services;


import java.util.ArrayList;

import com.smart.entities.Patient;
import com.smart.entities.Quiz;

public interface PatientServiceImpl {
    Quiz save(Quiz response);
    double subSession(int userid);
    
	Integer completed(Integer userid, Integer SectionId);
	
	ArrayList<Quiz> getResponse(int userid, int sectionid);
	ArrayList<Quiz> getDoctorView(int userid);
}
