package com.smart.Services;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.TreeSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.smart.entities.Patient;
import com.smart.entities.Quiz;

import com.smart.Repository.QuizRepository;

@Service
public class PatientService implements PatientServiceImpl{
    @Autowired
    private QuizRepository patientRepository;
   

    // TODO Auto-generated constructor stub
    public PatientService(QuizRepository patientRepository) {
        super();
        this.patientRepository = patientRepository;
    }



    @Override
    public Quiz save(Quiz response) {
        // TODO Auto-generated method stub
        Quiz patient1=new Quiz(
                response.getSectionID(),response.getSubSectionID(),response.getQid(),response.getPatient(),response.getResponse());
        

        return patientRepository.save(patient1);
    }
    @Override
    public double subSession(int userid)
    {
    	List<Quiz> details =(ArrayList<Quiz>) patientRepository
	            .findById(userid);
    	TreeSet<Double> section=new TreeSet();
    	
	    for(int i=0;i<details.size();i++)
	    {
	    	section.add( details.get(i).getSubSectionID());
	    }
	    Double current=section.last();
	    current=current+0.1;
	    System.out.println(current);
	    return current;}
    @Override
    public Integer completed(Integer userid,Integer SectionId)
    {
    	Integer m=patientRepository.findByIdandSectionId(userid, SectionId);
    	if(m!=5)
    		return 0;
    	else 
    		return 1;
    	
    }
    @Override
    public ArrayList<Quiz> getResponse(int userid,int sectionid)
    {
    	ArrayList<Quiz> p=patientRepository.findResponsebyIdandSectionId(userid,sectionid);
    	return p;
    }
    @Override
    public ArrayList<Quiz> getDoctorView(int userid)
    {
    	ArrayList<Quiz> details =(ArrayList<Quiz>) patientRepository
	            .findById(userid);
    	return details;
    }
    
}
