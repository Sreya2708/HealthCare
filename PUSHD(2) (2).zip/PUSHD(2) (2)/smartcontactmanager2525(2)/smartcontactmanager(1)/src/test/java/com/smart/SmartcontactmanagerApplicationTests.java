package com.smart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartcontactmanagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
